import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_swiper/flutter_swiper.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GemPlex Clone',
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return DefaultTabController(
      length: 8,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(120),
          child: AppBar(
            backgroundColor: Colors.black,
            leading: Icon(
              Icons.menu,
              color: Colors.white,
              size: 30.0,
            ),
            title: Text(
              "GemPlex",
              style: GoogleFonts.rubik(fontSize: 30, color: Colors.white),
            ),
            actions: <Widget>[
              Padding(
                  padding: EdgeInsets.only(right: 20.0),
                  child: GestureDetector(
                    onTap: () {},
                    child: Icon(
                      Icons.search,
                      color: Colors.white,
                      size: 30.0,
                    ),
                  )),
              Padding(
                  padding: EdgeInsets.only(right: 20.0),
                  child: GestureDetector(
                    onTap: () {},
                    child: Icon(
                      Icons.shopping_cart_rounded,
                      color: Colors.white,
                      size: 30,
                    ),
                  )),
            ],
            bottom: TabBar(
              indicatorWeight: 3,
              isScrollable: true,
              labelPadding: EdgeInsets.fromLTRB(20, 10, 20, 20),
              tabs: [
                Text('Home',
                    style:
                        GoogleFonts.rubik(fontSize: 13, color: Colors.white)),
                Text('Originals',
                    style:
                        GoogleFonts.rubik(fontSize: 13, color: Colors.white)),
                Text('Movies',
                    style:
                        GoogleFonts.rubik(fontSize: 13, color: Colors.white)),
                Text('Videos',
                    style:
                        GoogleFonts.rubik(fontSize: 13, color: Colors.white)),
                Text('Music',
                    style:
                        GoogleFonts.rubik(fontSize: 13, color: Colors.white)),
                Text('Trending',
                    style:
                        GoogleFonts.rubik(fontSize: 13, color: Colors.white)),
                Text('Hots',
                    style:
                        GoogleFonts.rubik(fontSize: 13, color: Colors.white)),
                Text('Details',
                    style:
                        GoogleFonts.rubik(fontSize: 13, color: Colors.white)),
              ],
            ),
          ),
        ),
        body: Container(
          color: Colors.black87,
          child: TabBarView(
            children: [
              firstPage(),
              firstPage(),
              firstPage(),
              firstPage(),
              firstPage(),
              firstPage(),
              firstPage(),
              firstPage(),
            ],
          ),
        ),
      ),
    );
  }

  Widget firstPage() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: Container(
                height: 130,
                color: Colors.white,
              ),
            ),
            SizedBox(
              height: 12,
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(0, 0, 8, 0),
                child: Row(
                  children: <Widget>[
                    Image.network(
                        'https://flutter-examples.com/wp-content/uploads/2019/09/blossom.jpg',
                        width: SizeConfig.screenWidth,
                        height: 170,
                        fit: BoxFit.fitWidth),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      color: Colors.green, // Yellow
                      height: 170,
                      width: SizeConfig.screenWidth,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                      color: Colors.pink, // Yellow
                      height: 170.0,
                      width: SizeConfig.screenWidth,
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Image.network(
                        'https://flutter-examples.com/wp-content/uploads/2019/09/blossom.jpg',
                        width: SizeConfig.screenWidth,
                        height: 170,
                        fit: BoxFit.fitWidth),
                    SizedBox(
                      width: 10,
                    ),
                    Container(
                        color: Colors.redAccent, // Yellow
                        height: 170.0,
                        width: SizeConfig.screenWidth),
                    SizedBox(
                      width: 10,
                    ),
                    Image.network(
                        'https://flutter-examples.com/wp-content/uploads/2019/09/blossom.jpg',
                        width: SizeConfig.screenWidth,
                        height: 170,
                        fit: BoxFit.fitWidth),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              height: 40,
              width: SizeConfig.screenWidth,
              child: Row(
                children: [
                  Container(
                    height: 35,
                    width: 4,
                    color: Colors.blue,
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Text('ORIGINALS',
                      style:
                          GoogleFonts.rubik(fontSize: 16, color: Colors.white)),
                ],
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Column(
              children: [
                Row(
                  children: [
                    Text("Series",
                        style: GoogleFonts.rubik(
                            fontSize: 13, color: Colors.lightBlueAccent[400])),
                    Spacer(),
                    Text("See more",
                        style: GoogleFonts.rubik(
                            fontSize: 10, color: Colors.white)),
                  ],
                )
              ],
            ),
            SizedBox(
              height: 10,
            ),
            SizedBox(
              height: 200.0,
              width: SizeConfig.screenWidth,
              child: ListView.builder(
                physics: ClampingScrollPhysics(),
                shrinkWrap: true,
                scrollDirection: Axis.horizontal,
                itemCount: 10,
                itemBuilder: (BuildContext context, int index) => Card(
                  elevation: 20,
                  child: Stack(
                    children: [
                      Container(
                          width: SizeConfig.screenWidth / 2.5,
                          child: Center(child: Text('Dummy Card Text'))),
                      Positioned(
                        right: 8,
                        top: 8,
                        child: Container(
                          width: 25.0,
                          height: 25.0,
                          decoration: BoxDecoration(
                              color: Colors.blue[500],
                              shape: BoxShape.circle,
                              border: Border.all(width: 1, color: Colors.blue)),
                          child: Icon(
                            Icons.add_shopping_cart_sharp,
                            color: Colors.white,
                            size: 15,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SizeConfig {
  static MediaQueryData _mediaQueryData;
  static double screenWidth;
  static double screenHeight;
  static double blockSizeHorizontal;
  static double blockSizeVertical;
  static double _safeAreaHorizontal;
  static double _safeAreaVertical;
  static double safeBlockHorizontal;
  static double safeBlockVertical;

  void init(BuildContext context) {
    _mediaQueryData = MediaQuery.of(context);
    screenWidth = _mediaQueryData.size.width;
    screenHeight = _mediaQueryData.size.height;
    blockSizeHorizontal = screenWidth / 100;
    blockSizeVertical = screenHeight / 100;
    _safeAreaHorizontal =
        _mediaQueryData.padding.left + _mediaQueryData.padding.right;
    _safeAreaVertical =
        _mediaQueryData.padding.top + _mediaQueryData.padding.bottom;
    safeBlockHorizontal = (screenWidth - _safeAreaHorizontal - 2) / 100;
    safeBlockVertical = (screenHeight - _safeAreaVertical) / 100;
  }
}
