package com.example.Gemplex_Clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
